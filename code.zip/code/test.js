let help = document.getElementById("cw");
let d = help.getContext("2d");

const ball = {
    x: 350,
    y: 300,
    vx: 5,
    vy: 2,
    radius: 30,
    stat: (Math.PI / 180),
    color: "yellow",
    draw() {
        d.beginPath();
        d.arc(this.x, this.y, this.radius, 0 ,stat * 30, stat * 330, true);
        d.lineTo(this.x, this.y)
        d.closePath();
        d.fillStyle = this.color;
        d.fill();
    }
};
