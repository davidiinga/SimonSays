
// new
let help = document.getElementById("cw");
let d = help.getContext("2d");

let stat = Math.PI / 180;

const ball = {
    x: 350,
    y: 300,
    vx: 5,
    vy: 2,
    radius: 30,
    stat: (Math.PI / 180),
    color: "yellow",
    draw() {
        d.beginPath();
        d.arc(this.x, this.y, this.radius, 0 ,stat * 30, stat * 330, true);
        d.lineTo(this.x, this.y)
        d.closePath();
        d.fillStyle = this.color;
        d.fill();
    }
};

function animate() {
    d.clearRect(0,0, help.width, help.height);
    ball.draw();
    ball.x += ball.vx;
    ball.y += ball.vy;
    ball.vy *= 1;
    ball.vy += 0.25;

    if (ball.y + ball.vy > help.height ||ball.y + ball.vy < 0) {
      ball.vy = -ball.vy;
    }
    if (ball.x + ball.vx > help.width || ball.x + ball.vx < 0) {
        ball.vx = -ball.vx;
    }

    window.requestAnimationFrame(animate);
}

animate();